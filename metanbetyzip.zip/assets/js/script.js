$(document).ready(function(){
    $('.single-faq h2').click(function(){
        $('.single-faq').removeClass('active');
        $(this).parent().toggleClass('active');
    });
});



setTimeout(() => {
    $('body').removeClass('y-scroll')
    $('#preloader').addClass('hide')
}, 900);


function openTab(evt, tabName) {
    var i, tabcontent, tablinks;

    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }

    tablinks = document.getElementsByClassName("tablink");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].style.backgroundColor = "";
    }

    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.style.backgroundColor = "#9DA8D62B";
}

document.addEventListener("DOMContentLoaded", function () {
    document.querySelector(".tablink").click();
});
